MedEST-Open final arXiv source package

Compile with:
  pdflatex main.tex
  pdflatex main.tex

This package contains:
  main.tex
  figures/*.pdf

The bibliography is embedded in main.tex using thebibliography, so no BibTeX step is required.
