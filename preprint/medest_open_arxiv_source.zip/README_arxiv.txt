MedEST-Open arXiv source package.

Build command:
  latexmk -pdf main.tex

The package intentionally includes only LaTeX source, references, and figure PDFs.
Raw data, model checkpoints, logs, generated embeddings, and rendered page images are excluded.
